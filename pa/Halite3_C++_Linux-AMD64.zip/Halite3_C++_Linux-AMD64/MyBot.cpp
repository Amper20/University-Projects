#include "hlt/game.hpp"
#include "hlt/constants.hpp"
#include "hlt/log.hpp"

#include <random>
#include <ctime>

using namespace std;
using namespace hlt;

double nearest_dropoff_distance(Position &square, shared_ptr<Player> &me, GameMap* game){

    double distance = (double)game->calculate_distance(square, me->shipyard->position);
    for (auto drop_iterator : me->dropoffs){
        distance = min(distance, (double)game->calculate_distance(square, drop_iterator.second->position));
    }

    return distance;
}

int main(int argc, char *argv[])
{
    unsigned int rng_seed;
    if (argc > 1)
    {
        rng_seed = static_cast<unsigned int>(stoul(argv[1]));
    }
    else
    {
        rng_seed = static_cast<unsigned int>(time(nullptr));
    }
    mt19937 rng(rng_seed);

    Game game;
    // At this point "game" variable is populated with initial map data.
    // This is a good place to do computationally expensive start-up pre-processing.
    // As soon as you call "ready" function below, the 2 second per turn timer will start.
    game.ready("MyCppBot");

    log::log("Successfully created bot! My Player ID is " + to_string(game.my_id) + ". Bot rng seed is " + to_string(rng_seed) + ".");

    for (;;)
    {
        game.update_frame();

        shared_ptr<Player> me = game.me;
        unique_ptr<GameMap> &game_map = game.game_map;

        vector<Command> command_queue;
        vector<shared_ptr<Ship>> blocked;
        Direction direction;

        for (const auto &ship_iterator : me->ships)
        {
            shared_ptr<Ship> ship = ship_iterator.second;
            if (game_map->at(ship)->halite / 10 <= ship->halite)
            {
                if (ship->state == constants::MINING){
                    // mine

                    //calculate best square to go
                    double lowest_score = 999999999;
                    MapCell* lowest = &(game_map->cells[0][0]);
                    
                    for (int x = 0; x < game_map->height; x++)
                    {
                        
                        for (int y = 0; y < game_map->width; y++)
                        {
                            double distance_ship_to_square = game_map->calculate_distance(ship->position, game_map->cells[x][y].position);
                            double distance_square_to_dropoff = nearest_dropoff_distance(game_map->cells[x][y].position, me, game_map.get());
                            double mining_rate = 0.4375 * game_map->cells[x][y].halite;
                            double estimate_time =  (1000 - ship->halite) / mining_rate;
                            double score = distance_ship_to_square + distance_square_to_dropoff + estimate_time;

                            if (lowest_score > score)
                            {
                                lowest_score = score;
                                lowest = &(game_map->cells[x][y]);
                            }
                        }
                    }
                    if (ship->halite >= 900)
                        ship->state = constants::RETURN;
                    else
                    {
                            
                        log::log("score_final1:" + to_string(lowest_score) + " " + lowest->position.to_string() + "\n");
                        // go to that square mark as unsable
                        // lowest->mark_unsafe(ship);
                        direction = game_map->naive_navigate(ship, lowest->position);
                        if(direction != Direction::BLOCKED)
                            command_queue.push_back(ship->move(direction));
                        else
                        {
                            blocked.push_back(ship);
                        }
                                
                    }
                }
                if (ship->state == constants::RETURN)
                {   
                    direction = game_map->naive_navigate(ship, me->shipyard->position );
                    if(direction != Direction::BLOCKED && direction != Direction::STILL)
                        command_queue.push_back(ship->move(direction));
                    else
                        blocked.push_back(ship);
                    //return to dropof
                    if (ship->halite <= 0)
                        ship->state = constants::MINING;
                }                
                    
            }
            else
            {
                command_queue.push_back(ship->stay_still());
            }
        }
        
        if(blocked.size()){
            int u = 0;
            for(auto it : blocked){
                if(u)
                    break;
                if(it->state == constants::RETURN){
                    Position ret_pos = it->position;
                    for(auto it1 : blocked){
                        if(it != it1 && it1->state == constants::MINING && game_map->calculate_distance(it->position, it1->position) <= 1){
                            u = 1;
                            log::log("pzdms\n");
                            direction = game_map->unsafe_navigate(it, it1->position);
                            command_queue.push_back(it->move(direction));

                            direction = game_map->unsafe_navigate(it1, it->position);
                            command_queue.push_back(it1->move(direction));
                        }
                    }
                }
            }
        }

        if (
            game.turn_number <= 75 &&
            me->halite >= constants::SHIP_COST &&
            !game_map->at(me->shipyard)->is_occupied())
        {
            command_queue.push_back(me->shipyard->spawn());
        }

        if (!game.end_turn(command_queue))
        {
            break;
        }          
    }

    return 0;
}
